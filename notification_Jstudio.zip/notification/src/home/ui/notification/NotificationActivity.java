package home.ui.notification;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.app.PendingIntent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class NotificationActivity extends Activity {
    
    // On définit une variable global qui sera
    // l'id unique correspondant à notre notification
    public static final int ID_NOTIFICATION = 1234;
 
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_main);
 
        // On récupère nos deux boutons créés en XML grâce à leur id
        Button boutonCreateNotif = (Button) findViewById(R.id.CreateNotif);
        Button boutonClearNotif = (Button) findViewById(R.id.ClearNotif);  
 
        //On applique un écouteur d'évènement à notre bouton "Créer une notification"
        boutonCreateNotif.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                //on lance la méthode createNotify (qui comme son nom l'indique créera la notification)
                createNotify();
            }
        });
 
        //On applique un écouteur d'évènement à notre bouton "Supprimer la notification"
        boutonClearNotif.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                //on lance la méthode cancelNotify (qui supprimera la notification de la liste des notifications)
                cancelNotify();
            }
        }); 
    }
 
    //Méthode qui crée la notification
    private void createNotify(){
        NotificationChannel notificationChannel = new NotificationChannel(Integer.toString(ID_NOTIFICATION),"Simple_Notification", NotificationManager.IMPORTANCE_DEFAULT);
        
        NotificationManager notificationManager = (NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);
        notificationManager
            .createNotificationChannel(notificationChannel);
        
        Notification.Builder notification = new Notification.Builder(this, Integer.toString(ID_NOTIFICATION));
        
        Intent intent = new Intent(this, NotificationLaunch.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, 0);
        
        notification
            .setSmallIcon(R.drawable.icon)
            .setBadgeIconType(Notification.BADGE_ICON_SMALL)
            .setContentTitle("notification title")
            .setContentText("notification message")
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            ;
        
        try {
            notificationManager.notify(ID_NOTIFICATION, notification.build());
        } catch(Exception e) {
            android.widget.Toast.makeText(this, e.toString(), android.widget.Toast.LENGTH_LONG);
        }
    }
 
    //Méthode pour supprimer de la liste de notification la notification que l'on vient de créer
    private void cancelNotify(){
        //On crée notre gestionnaire de notification
        NotificationManager notificationManager = (NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);
        //on supprime la notification grâce à son ID
        notificationManager.cancel(ID_NOTIFICATION);
    }
    
}